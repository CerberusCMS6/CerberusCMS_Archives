<?php
/*
 ============================================================================================================
 + ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 + ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 + Cerberus Content Management System
 + ----------------------------------------------------------------------------------------------------------
 + - Author			 : Gary Christopher Johnson of Oildale In Southern California
 + - Company			 : CerberusCMS, Free and Open Source Software
 + - Company Address		 : Oildale In Southern California, United States of America
 + - Electronic Mail Address	 : CerberusCMS6@Proton.me
 + - Document Notes		 : View this file in a non-formatting text editor without word-wrap for the
 +				 : correct display of this programming code and its indentation.
 + ----------------------------------------------------------------------------------------------------------
 +    ()    () - -
 +  ()  () ()()()()
 +  ------
 + Index Application
 + ----------------------------------------------------------------------------------------------------------
 + - This File, Location	 : Master Root Directory => Root Directory => index.php
 + - This File, Version		 : 0.7.7
 + - This File, Programming Code : Pure Pre-Hyper-Text-Post-Processor
 + - Programming Code Model	 : Procedural, Functional, Object Oriented :: Pre-Order Algebraic
 + -				 :					   :: Pre-Order Logical
 + - Compatibility		 : Extensible-Markup-Language		   :: Version Numbers: 1, 1.1
 + - Compatibility		 : Hyper-Text-Markup-Language		   :: Version Numbers: 1, 2, 3, 4, 5
 + - Compatibility		 : Pre-Hyper-Text-Post-Processor 	   :: Version Numbers: 5, 7, 8
 + - Compatibility		 : Zend Engine				   :: Version Numbers: 3, 4
 + - Official Release Date	 : Saturday, April 19th of 2025
 + ----------------------------------------------------------------------------------------------------------
 + -------------------------------------------------------------------------------      - Titan -
 + --[][]--[][][]--[][][]--[][][]---[][][]--[][][]--[]--[]------[][][]------------   []++++||=======>
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]----------------
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]----------------    |'-._/\_.-'|
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]----------------    |    []    |
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]----------------    |___-[]-___|
 + -[]-----[][][]--[][][]--[][][]---[][][]--[][][]--[]--[]------[]----------------    |__((**))__|
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]----------------    \   -[]-   /
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]------------/-\-     \   []   /
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]---VERSION--|6|-	\  []  /
 + --[][]--[][][]--[]--[]--[][][]---[][][]--[]--[]--[][][]--[][][]------------\-/-	 '.[].'
 + -------------------------------------------------------------------------------
 + ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Build Number: 01 ~ Final
 + ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Edit Number : 0,005
 ============================================================================================================
*/

/*
 ============================================================================================================
 +
 +
 +
 + [ ^ ] Master Index File
 +
 +
 +
 ============================================================================================================
*/

/*
 ============================================================================================================
 +
 + Master Index File :: Includes
 +
 ============================================================================================================
*/

/*
 ============================================================================================================
 + Master Index File :: Includes :: System Configuration File
 ============================================================================================================
*/

include_once "./System/Configuration/Global_Configuration.php";

/*
 ============================================================================================================
 +
 + Master Index File :: Variables
 +
 ============================================================================================================
*/

/*
 ============================================================================================================
 + Master Index File :: Variables :: Installation Application File
 ============================================================================================================
*/

$_Project_File_Installation				= "./Architect.php";

/*
 ============================================================================================================
 + Master Index File :: Variables :: Kernel Application File
 ============================================================================================================
*/

$_Project_File_Kernel					= "./$_INTERNAL_FILE_KERNEL";
$_Project_File_Kernel_Default_Application		= "./$_INTERNAL_FILE_KERNEL?$_INTERNAL_APPLICATION_MODULE_MEMBER=News";

/*
 ============================================================================================================
 + Master Index File :: Variables :: Root Index File
 ============================================================================================================
*/

$_Project_File_Index					= "./index.php";

/*
 ============================================================================================================
 +
 + Master Index File :: File Checks
 +
 ============================================================================================================
*/

/*
 ============================================================================================================
 + IF: File DOES NOT Exist: Kernel File :: Flash :: Kernel File From Backup
 ============================================================================================================
*/

if (!file_exists($_Project_File_Kernel)) {

	copy("./System/Kernel/Backup/Current.kernel","$_Project_File_Kernel");
	header("location: ./Maintenance/Repair/$_INTERNAL_FILE_MAINTENANCE_REPAIR");

} else { // [ + ] ELSE: File DOES Exist: Kernel File, Check For Kernel File Size

	header("location: $_Project_File_Kernel_Default_Application");

} // [ + ] IF: File DOES NOT Exist: Kernel File :: Flash :: Kernel File From Backup

/*
 ============================================================================================================
 + IF: File Size: Kernel File :: Is: Less Than OR Equal To: 4096 Bytes :: Flash :: Kernel File From Backup
 ============================================================================================================
*/

if (filesize($_Project_File_Kernel) <= "4096") {

	copy("./System/Kernel/Backup/Current.kernel","$_Project_File_Kernel");
	header("location: ./Maintenance/Repair/$_INTERNAL_FILE_MAINTENANCE_REPAIR");

} // [ + ] IF: File Size: Kernel File :: Is: Less Than OR Equal To: Zero :: Flash :: Kernel File From Backup

/*
 ============================================================================================================
 +
 + Master Index File :: Re-Directs
 +
 ============================================================================================================
*/

/*
 ============================================================================================================
 + Check For The Installation File: IF It Exists, Re-Direct To It
 ============================================================================================================
*/

if (file_exists($_Project_File_Installation)) {

	header("location: $_Project_File_Installation");

/*
 ============================================================================================================
 + Check For The Installation File: IF It Does Not Exists, Re-Direct To The Kernel File
 ============================================================================================================
*/

} else { // [ + ] ELSE: The Installation File DOES NOT Exist, Redirect To The Kernel File

	header("location: $_Project_File_Kernel_Default_Application");

} // [ + ] IF: File Exists: Architect Installation Application
?>